#!/bin/bash

# Quick start script for Firewall App

echo "Starting Firewall App..."
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "This app requires administrator privileges for network monitoring."
    echo "Restarting with sudo..."
    echo ""
    exec sudo "$0" "$@"
fi

# Run the firewall
cd "$(dirname "$0")"
python3 firewall_main.py "$@"
