"""
macOS Packet Filter (pf) controller
Interfaces with the built-in pf firewall
"""
import subprocess
import re
from typing import List, Dict, Optional


class PacketFilterController:
    def __init__(self):
        self.pf_conf_path = "/etc/pf.conf"
        self.custom_anchor = "firewall_app"
        self.rules_file = "/tmp/firewall_app_rules.conf"
    
    def check_pf_enabled(self) -> bool:
        """Check if pf is enabled"""
        try:
            result = subprocess.run(
                ['sudo', 'pfctl', '-s', 'info'],
                capture_output=True,
                text=True,
                check=False
            )
            return 'Status: Enabled' in result.stdout
        except Exception as e:
            print(f"Error checking pf status: {e}")
            return False
    
    def enable_pf(self) -> bool:
        """Enable pf firewall"""
        try:
            subprocess.run(['sudo', 'pfctl', '-e'], check=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error enabling pf: {e}")
            return False
    
    def disable_pf(self) -> bool:
        """Disable pf firewall"""
        try:
            subprocess.run(['sudo', 'pfctl', '-d'], check=True)
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error disabling pf: {e}")
            return False
    
    def setup_anchor(self) -> bool:
        """Set up custom anchor for our rules"""
        try:
            # Check if anchor already exists in pf.conf
            with open(self.pf_conf_path, 'r') as f:
                content = f.read()
            
            anchor_line = f"anchor \"{self.custom_anchor}\""
            load_line = f"load anchor \"{self.custom_anchor}\" from \"{self.rules_file}\""
            
            if anchor_line not in content:
                # Need to add our anchor
                # This is tricky - we'd need to modify /etc/pf.conf
                # For now, we'll use pfctl commands directly
                pass
            
            return True
        except Exception as e:
            print(f"Error setting up anchor: {e}")
            return False
    
    def apply_rules(self, rules: List[Dict]) -> bool:
        """
        Apply firewall rules to pf
        Rules format: [
            {'app_path': '/path/to/app', 'dest_ip': '1.2.3.4', 'dest_port': 443, 'action': 'block'},
            ...
        ]
        """
        try:
            # Generate pf rules file
            pf_rules = []
            
            for rule in rules:
                action = "block" if rule.get('action') == 'block' else "pass"
                
                # Build rule components
                rule_parts = [action, "out", "quick"]
                
                # Add destination IP if specified
                if rule.get('dest_ip'):
                    rule_parts.append(f"to {rule['dest_ip']}")
                
                # Add port if specified
                if rule.get('dest_port'):
                    rule_parts.append(f"port {rule['dest_port']}")
                
                pf_rules.append(" ".join(rule_parts))
            
            # Write rules to file
            with open(self.rules_file, 'w') as f:
                f.write("# Firewall App Rules\n")
                for rule in pf_rules:
                    f.write(f"{rule}\n")
            
            # Load rules using pfctl
            # Note: This requires proper anchor setup in /etc/pf.conf
            # For a working implementation, we'd need:
            # 1. Add anchor to /etc/pf.conf (requires admin)
            # 2. Or use pfctl -f to load rules directly (overrides existing)
            
            # For now, we'll document this limitation
            print("Note: Full pf integration requires anchor setup in /etc/pf.conf")
            print(f"Rules written to: {self.rules_file}")
            
            return True
            
        except Exception as e:
            print(f"Error applying rules: {e}")
            return False
    
    def get_active_connections(self) -> List[Dict]:
        """
        Get list of active network connections using lsof
        Returns list of connection info dictionaries
        """
        try:
            # Use lsof to get network connections
            result = subprocess.run(
                ['sudo', 'lsof', '-i', '-n', '-P'],
                capture_output=True,
                text=True,
                check=False
            )
            
            connections = []
            lines = result.stdout.split('\n')[1:]  # Skip header
            
            for line in lines:
                if not line.strip():
                    continue
                
                parts = line.split()
                if len(parts) < 9:
                    continue
                
                try:
                    # Parse lsof output
                    # Format: COMMAND PID USER FD TYPE DEVICE SIZE/OFF NODE NAME
                    command = parts[0]
                    pid = parts[1]
                    user = parts[2]
                    connection_info = parts[8]  # NAME column
                    
                    # Parse connection info (e.g., "192.168.1.1:443->192.168.1.2:12345")
                    if '->' in connection_info:
                        local, remote = connection_info.split('->')
                        if ':' in remote:
                            remote_ip, remote_port = remote.rsplit(':', 1)
                            
                            connections.append({
                                'app_name': command,
                                'pid': pid,
                                'destination_ip': remote_ip,
                                'destination_port': int(remote_port) if remote_port.isdigit() else 0
                            })
                except (ValueError, IndexError):
                    continue
            
            return connections
            
        except Exception as e:
            print(f"Error getting connections: {e}")
            return []
    
    def get_app_path_from_pid(self, pid: str) -> Optional[str]:
        """Get full application path from PID"""
        try:
            result = subprocess.run(
                ['ps', '-p', pid, '-o', 'comm='],
                capture_output=True,
                text=True,
                check=False
            )
            return result.stdout.strip() if result.returncode == 0 else None
        except Exception:
            return None
    
    def block_connection(self, dest_ip: str, dest_port: Optional[int] = None) -> bool:
        """
        Dynamically block a connection using pfctl
        """
        try:
            # Add a dynamic rule to block this connection
            rule = f"block out quick to {dest_ip}"
            if dest_port:
                rule += f" port {dest_port}"
            
            # Use pfctl to add the rule to a table
            # This is a simplified version - full implementation would need proper anchor management
            subprocess.run(
                ['sudo', 'pfctl', '-t', 'blocked_hosts', '-T', 'add', dest_ip],
                check=False
            )
            
            return True
        except Exception as e:
            print(f"Error blocking connection: {e}")
            return False
