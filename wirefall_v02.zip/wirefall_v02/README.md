# WireFall  v0.2  🔒

A Python-based bidirectional network firewall for macOS.
Monitors, logs, and controls both inbound and outbound connections.

## What's new in v0.2

| # | Improvement |
|---|-------------|
| 1 | **Timestamps** — logs now show `09 Feb 2026  17:44:49` instead of raw ISO string |
| 2 | **Drag-and-drop app** into Add Rule dialog (auto-fills name & path). Fallback Browse button always available. |
| 3 | **IN / OUT direction** — every log row shows `→ OUT` or `← IN` with colour coding (amber / blue) |
| 4 | **Path column** now visible in the Rules tab |
| 5 | **No more freeze** — popups are fully non-blocking; missing the countdown never hangs the app |
| 6 | **Multi-IP & port ranges** when adding rules manually: `80,443` or `8000-8010` or `1.2.3.4, 5.6.7.8` |
| 7 | **Preferences tab** — poll interval, popup timeout, DNS toggle |
| 8 | **Log filters** — filter by app name and allow/block action in real time |
| 9 | **Dark UI** — full dark theme with colour-coded allow (green) / block (red) rows |
| 10 | **Rule specificity scoring** — most-specific rule wins instead of first-match |
| 11 | **Auto-refresh** logs every N seconds (configurable in Preferences) |
| 12 | **Remember defaults ON** in popup (was OFF in v0.1) |

## Quick start

```bash
cd wirefall_v02
bash setup.sh
sudo python3 firewall_main.py
```

## File structure

```
wirefall_v02/
├── firewall_main.py       ← entry point
├── src/
│   ├── gui.py             ← main window + popup
│   ├── database.py        ← SQLite rules & logs
│   ├── connection_monitor.py  ← lsof watcher
│   └── pf_controller.py   ← macOS pf interface
├── setup.sh
├── start_firewall.sh
└── test_installation.py
```

## Known limitations (still v0.x)

- pf actual blocking requires anchor setup in `/etc/pf.conf` (see README v0.1)
- No menu-bar icon yet (plan B / App Store version)
- tkdnd package needed for true drag-and-drop; Browse button is the reliable fallback
- No VPN traffic visibility

## Roadmap

- **v0.3** — menu-bar icon, macOS Notification Center alerts
- **Plan B** — App Store packaging, sandboxed network extension
