#!/bin/bash

# Firewall App Setup Script for macOS

echo "==================================="
echo "Firewall App Setup"
echo "==================================="
echo ""

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed"
    echo "Please install Python 3 from https://www.python.org"
    exit 1
fi

echo "Python 3 found: $(python3 --version)"
echo ""

# Check Python version (need 3.7+)
python3 -c "import sys; exit(0 if sys.version_info >= (3, 7) else 1)"
if [ $? -ne 0 ]; then
    echo "Error: Python 3.7 or higher is required"
    exit 1
fi

echo "Installing Python dependencies..."
echo ""

# Install required packages
pip3 install --break-system-packages tk || {
    echo "Note: Tkinter should be included with Python on macOS"
}

echo ""
echo "==================================="
echo "Setup Complete!"
echo "==================================="
echo ""
echo "To run the firewall:"
echo "  sudo python3 firewall_main.py"
echo ""
echo "Note: sudo is required for network monitoring features"
echo ""
echo "The application will:"
echo "  - Monitor all network connections"
echo "  - Show popups for unknown connections"
echo "  - Log all connection attempts"
echo "  - Allow you to create rules"
echo ""
echo "First time setup:"
echo "  1. Start the app with: sudo python3 firewall_main.py"
echo "  2. The GUI will open with 'Block All' mode by default"
echo "  3. As apps try to connect, you'll see popups"
echo "  4. Choose Allow or Block, and optionally 'Remember'"
echo "  5. Switch to 'Allow All' mode to just log connections"
echo "  6. Export logs/rules to .md files anytime"
echo ""
