#!/usr/bin/env python3
"""
Test script for Firewall App
Verifies installation and basic functionality without requiring sudo
"""

import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

def test_imports():
    """Test that all required modules can be imported"""
    print("Testing imports...")
    
    try:
        import tkinter
        print("  ✓ tkinter")
    except ImportError:
        print("  ✗ tkinter - MISSING")
        print("    Install Python 3 from python.org to get tkinter")
        return False
    
    try:
        import sqlite3
        print("  ✓ sqlite3")
    except ImportError:
        print("  ✗ sqlite3 - MISSING")
        return False
    
    try:
        import subprocess
        print("  ✓ subprocess")
    except ImportError:
        print("  ✗ subprocess - MISSING")
        return False
    
    try:
        import threading
        print("  ✓ threading")
    except ImportError:
        print("  ✗ threading - MISSING")
        return False
    
    return True


def test_database():
    """Test database operations"""
    print("\nTesting database...")
    
    try:
        from database import FirewallDB
        
        # Create test database
        db = FirewallDB("test_firewall.db")
        print("  ✓ Database created")
        
        # Add test rule
        rule_id = db.add_rule(
            app_name="TestApp",
            dest_ip="1.2.3.4",
            dest_port=443,
            action="block",
            notes="Test rule"
        )
        print(f"  ✓ Rule added (ID: {rule_id})")
        
        # Get rules
        rules = db.get_rules()
        assert len(rules) == 1
        print(f"  ✓ Retrieved {len(rules)} rule(s)")
        
        # Add log entry
        db.add_log_entry(
            app_name="TestApp",
            dest_ip="1.2.3.4",
            dest_port=443,
            action="block"
        )
        print("  ✓ Log entry added")
        
        # Get logs
        logs = db.get_logs()
        assert len(logs) == 1
        print(f"  ✓ Retrieved {len(logs)} log(s)")
        
        # Test repeat count
        db.add_log_entry(
            app_name="TestApp",
            dest_ip="1.2.3.4",
            dest_port=443,
            action="block"
        )
        logs = db.get_logs()
        assert logs[0]['repeat_count'] == 2
        print(f"  ✓ Repeat count working (count: {logs[0]['repeat_count']})")
        
        # Test export
        db.export_rules_to_markdown("test_rules.md")
        print("  ✓ Rules exported to test_rules.md")
        
        db.export_logs_to_markdown("test_logs.md")
        print("  ✓ Logs exported to test_logs.md")
        
        # Cleanup
        os.remove("test_firewall.db")
        os.remove("test_rules.md")
        os.remove("test_logs.md")
        print("  ✓ Cleanup complete")
        
        return True
        
    except Exception as e:
        print(f"  ✗ Database test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_pf_controller():
    """Test packet filter controller (basic checks only)"""
    print("\nTesting packet filter controller...")
    
    try:
        from pf_controller import PacketFilterController
        
        pf = PacketFilterController()
        print("  ✓ PacketFilterController created")
        
        # Note: We can't test actual pf operations without sudo
        print("  ℹ Full pf tests require sudo (skipped)")
        
        return True
        
    except Exception as e:
        print(f"  ✗ PF controller test failed: {e}")
        return False


def test_connection_monitor():
    """Test connection monitor (basic checks only)"""
    print("\nTesting connection monitor...")
    
    try:
        from connection_monitor import ConnectionMonitor
        
        def dummy_callback(**kwargs):
            pass
        
        monitor = ConnectionMonitor(callback=dummy_callback)
        print("  ✓ ConnectionMonitor created")
        
        # Don't actually start monitoring without sudo
        print("  ℹ Full monitoring tests require sudo (skipped)")
        
        return True
        
    except Exception as e:
        print(f"  ✗ Connection monitor test failed: {e}")
        return False


def main():
    """Run all tests"""
    print("=" * 50)
    print("Firewall App - Installation Test")
    print("=" * 50)
    print()
    
    print(f"Python version: {sys.version}")
    print()
    
    all_passed = True
    
    # Run tests
    all_passed &= test_imports()
    all_passed &= test_database()
    all_passed &= test_pf_controller()
    all_passed &= test_connection_monitor()
    
    print()
    print("=" * 50)
    
    if all_passed:
        print("✓ All tests passed!")
        print()
        print("Installation is complete and working.")
        print()
        print("To start the firewall, run:")
        print("  sudo python3 firewall_main.py")
        print()
        print("Or use the convenience script:")
        print("  ./start_firewall.sh")
        print()
        return 0
    else:
        print("✗ Some tests failed")
        print()
        print("Please check the errors above and fix them.")
        print("You may need to install Python 3 from python.org")
        print()
        return 1


if __name__ == '__main__':
    sys.exit(main())
